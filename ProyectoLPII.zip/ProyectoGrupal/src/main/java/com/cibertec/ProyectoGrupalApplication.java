package com.cibertec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoGrupalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoGrupalApplication.class, args);
	}

}
